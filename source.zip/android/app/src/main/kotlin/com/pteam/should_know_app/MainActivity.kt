package com.pteam.should_know_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
