package com.example.apk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
