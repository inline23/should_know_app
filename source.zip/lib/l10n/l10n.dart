import 'dart:ui';

class L10n {
  static final all = [
    const Locale("ar"),
    const Locale("en"),
  ];
}
